from gi.repository.IBus import \
    AttrList, \
    Attribute, \
    Bus, \
    Component, \
    Config, \
    Engine, \
    EngineDesc, \
    Factory, \
    HotkeyProfile, \
    Keymap, \
    LookupTable, \
    Object, \
    ObservedPath, \
    PanelService, \
    PropList, \
    Property, \
    Proxy, \
    Serializable, \
    Service, \
    Text
